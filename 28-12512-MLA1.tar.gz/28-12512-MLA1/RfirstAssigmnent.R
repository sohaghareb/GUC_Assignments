trainingPhase <- function() {
#load the data into 3 vectors one for sepal ,one for petal and one for the species
#the cols names are shifted in the csv fies 
data <- read.csv(file="iris_sub_21655.csv",head=TRUE,sep=",")
sepal<- data$petal
petal<- data$species
dataOutput <- data$X
result <- vector(mode="numeric", length=0)
#loop over the coloumn species and  store 1 for setosa and -1 for versicolor
for (i in 1:100){
  #print(dataOutput[i])
  if(is.na(dataOutput[i]) == FALSE & grepl(dataOutput[i],"setosa") == TRUE){
    result<- c(result,1)
  }else{
    result<- c(result,-1)
  }
}

print("covariance between petal and iris ")
print(cov(petal,result))

print("correlation between petal and iris ")
print(cor(petal,result))

print("covariance between sepal and iris ")
print(cov(sepal,result))

print("correlation between sepal and iris ")
print(cor(sepal,result))

plot(sepal,result)
axis(side=2,at=seq(0, 2, by=0.1))
box()
rand<-runif(1, -1, 1)
weights<-rand
#2nd weight
rand<-runif(1, -1, 1)
weights<-c(weights,rand)
###########################
loops<-0
error<-0
learningRate <- 0.2
pointer<-0 #pointer to access error result vetor
errorresults<- vector(mode="numeric", length=0)#store the error results for plotting
corrctprediction<- 0 #count number of correct prediction
#print(weights)
while (corrctprediction < 100) {
  corrctprediction<-0
  for(i in 1:100){
    #calculate the activation
     calculatedOutput<-weights[1] * sepal[i] + 
     weights[2] * petal[i]
     if(calculatedOutput> 0)
       calculatedOutput=1
     else
       calculatedOutput=-1
     #count number of corect results
     if(calculatedOutput == result[i]){
       corrctprediction =corrctprediction +1;
       
     }
     #calculate the error
     error<-calculatedOutput-result[i]
     errorresults[pointer]<- error
     pointer<- pointer+1
     #update the weights
     weights[1]=(weights[1]-error *learningRate * sepal[i])
     weights[2]=(weights[2]-error *learningRate*petal[i])
    
  }
  loops=loops+1
}

print("correct prediction is ")
print(corrctprediction)
print("After iterations ")
print(loops)

print("weights are ")
print(weights)

return (weights)
}
#it takes the 3 records we have in the assignment and test them
testingPhase<- function(SepalLength1,PetalLength1,SepalLength2,PetalLength2,SepalLength3,PetalLength3) {
  ww<-trainingPhase()
  calc=ww[1]*SepalLength1 + ww[2]*PetalLength1
  print(calc)
  if(calc >0)
    print("Setosa")
  else
    print("Versicolor")
  ##########
  calc=ww[1]*SepalLength2 + ww[2]*PetalLength2
  print(calc)
  if(calc >  0)
    print("Setosa")
  else
    print("Versicolor")
  ##################3
  calc=ww[1]*SepalLength3 + ww[2]*PetalLength3
  print(calc)
  if(calc > 0)
    print("Setosa")
  else
    print("Versicolor")
  
  
}




