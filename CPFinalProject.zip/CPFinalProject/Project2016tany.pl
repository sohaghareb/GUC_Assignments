:- use_module( library(clpfd)).
%schedule(31 , 0 ,[1] ,[f,f,f,f,a],[10,20,5,21,2],[7,7,7,7,7,7,7],[[5],[5],[5],[5],[5]],
% [[ [1] ,[7],[12],[17]],[ [3],[8],[13],[18]],[[4],[9],[14],[19]],[ [5],[18],[15],[20] ],[[1],[6],[11],[16]]],FinalScedule)


preprocessing(CourseSchedule,StudentID,SoftConstrain,FinalScedule):- % no ptimization over gabs and days off
	SoftConstrain is 0,
	history(StudentID,History),
	obligatory(StudentID,Obligatory),
	allowed_credit_hours(StudentID,AllowedCH),
	not_probation(StudentID,NotProbabation),
	credit_hours(StudentID,CHRS),
	course_semester(StudentID,CourseSemester),
	prequisites(StudentID,Prequesities),
	AllowedCH2 is AllowedCH + 3*NotProbabation,            %if he is not probation i will add 3 credit hours
	remaining_hours(CHRS,Obligatory,AllowedCH2,RemainingCH), %what are remaining hours after excluding the the obligatory?	
	courses_not_obligatory(Prequesities,History,Obligatory,Result,1), %get the not obligatory courses that he already took the prequisites
	schedule0(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule).
	
	
preprocessing(CourseSchedule,StudentID,SoftConstrain,FinalScedule):-%optimize on gaps only
	SoftConstrain is 1,
	history(StudentID,History),
	obligatory(StudentID,Obligatory),
	allowed_credit_hours(StudentID,AllowedCH),
	not_probation(StudentID,NotProbabation),
	credit_hours(StudentID,CHRS),
	course_semester(StudentID,CourseSemester),
	prequisites(StudentID,Prequesities),
	AllowedCH2 is AllowedCH + 3*NotProbabation,            %if he is not probation i will add 3 credit hours
	remaining_hours(CHRS,Obligatory,AllowedCH2,RemainingCH), %what are remaining hours after excluding the the obligatory?	
	courses_not_obligatory(Prequesities,History,Obligatory,Result,1), %get the not obligatory courses that he already took the prequisites
	schedule1(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule).
	
preprocessing(CourseSchedule,StudentID,SoftConstrain,FinalScedule):- %optimize on days off only 
	SoftConstrain is 2,
	history(StudentID,History),
	obligatory(StudentID,Obligatory),
	allowed_credit_hours(StudentID,AllowedCH),
	not_probation(StudentID,NotProbabation),
	credit_hours(StudentID,CHRS),
	course_semester(StudentID,CourseSemester),
	prequisites(StudentID,Prequesities),
	AllowedCH2 is AllowedCH + 3*NotProbabation,            %if he is not probation i will add 3 credit hours
	remaining_hours(CHRS,Obligatory,AllowedCH2,RemainingCH), %what are remaining hours after excluding the the obligatory?	
	courses_not_obligatory(Prequesities,History,Obligatory,Result,1), %get the not obligatory courses that he already took the prequisites
	schedule2(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule).
	
preprocessing(CourseSchedule,StudentID,SoftConstrain,FinalScedule):- %optimize on days off and gaps 
	SoftConstrain is 3,
	history(StudentID,History),
	obligatory(StudentID,Obligatory),
	allowed_credit_hours(StudentID,AllowedCH),
	not_probation(StudentID,NotProbabation),
	credit_hours(StudentID,CHRS),
	course_semester(StudentID,CourseSemester),
	prequisites(StudentID,Prequesities),
	AllowedCH2 is AllowedCH + 3*NotProbabation,            %if he is not probation i will add 3 credit hours
	remaining_hours(CHRS,Obligatory,AllowedCH2,RemainingCH), %what are remaining hours after excluding the the obligatory?	
	courses_not_obligatory(Prequesities,History,Obligatory,Result,1), %get the not obligatory courses that he already took the prequisites
	schedule3(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule).

history(28-12512,[f,f,f,f,f]).
history(28-888,[f,f]).


obligatory(28-12512,[3,4]).
obligatory(28-888,[1]).


not_probation(28-12512,0).
not_probation(28-888,0).


allowed_credit_hours(28-12512,40).
allowed_credit_hours(28-888,50).


credit_hours(28-12512,[4,2,6,15,15]).
credit_hours(28-888,[20,20]).


course_semester(28-12512,[1,1,3,3,3]).
course_semester(28-888,[1,7]).


prequisites(28-12512,[[],[],[],[],[]]).
prequisites(28-888,[[],[]]).


schedule3(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule):-
		
	length(Result,L),
	length(ChosenCoursesBinary,L),
	ChosenCoursesBinary ins 0..1 ,%should have labeling on
	
	sum_up(ChosenCoursesBinary,Result,CHRS,Sum,1,NotObligatory1), %it takes 1) courses chosen 11011 2) result [3,5,10] courses i can take 3) CHRS  
	Sum #=<RemainingCH,
	labeling([max(Sum)],ChosenCoursesBinary),
	get_indices(ChosenCoursesBinary,Result,1,NotObligatory2),
	filterList(0, NotObligatory2, NotObligatory),
	%write('not obligatry chosen '),write(NotObligatory),nl,
	
	append(NotObligatory,Obligatory,AllCourses),     %append all courses together to scedule them at once
	%should be modified to have no oring
	helper(AllCourses,CourseSchedule,Slots,Pairs,SoftLabTut,CourseSemester,Soft), %scedule the courses
	%write('after helper '),nl,
	all_different(Slots),                             %each thing should have a diff slot 
	
	
	insertSort(Slots, SortedSlots),   %this to minimize the gaps 
	sum_gaps(SortedSlots,GapSum),
	dayOff(SortedSlots,DaysOff),
	
	
	DaysOff #>= 1,
	
	append(Slots,ChosenCoursesBinary,LabelingSlots),
	%what we will label on
	
	labeling([max(Sum),min(GapSum),max(DaysOff),max(Soft)],LabelingSlots),%max(Sum),min(GapSum),max(DaysOff),max(Soft)
	write(Pairs).
	%nl,write(ChosenCoursesBinary),nl,write(NotObligatory).
	%write('credit hurs taken '),write(Sum),
	%write('remaining CHRS '),write(RemainingCH).
	
indices(L,Index):-
	zs_maximum_at(L,Max,Pos),Max #> 0 ,
	rewrite(L,Pos,1,LNew),
	indices(LNew,Index2),
	append(Index2,[Pos],Index).
indices(L,[]):-
	zs_maximum_at(L,Max,Pos),Max #<1.

zs_maximum_at(Zs,Max,Pos) :-
   maplist(#>=(Max),Zs),
   nth1(Pos,Zs,Max).
rewrite([],Pos,I,[]).	
rewrite([H|T],Pos,I,[HN|TN]):-
		I #= Pos #==> HN #= 0,
		I #\= Pos #==> HN #= H,
		I2 #= I+1,
		rewrite(T,Pos,I2,TN).

	
schedule2(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule):-
		
	length(Result,L),
	length(ChosenCoursesBinary,L),
	ChosenCoursesBinary ins 0..1 ,%should have labeling on
	
	sum_up(ChosenCoursesBinary,Result,CHRS,Sum,1,NotObligatory1), %it takes 1) courses chosen 11011 2) result [3,5,10] courses i can take 3) CHRS  
	Sum #=<RemainingCH,
	labeling([max(Sum)],ChosenCoursesBinary),
	get_indices(ChosenCoursesBinary,Result,1,NotObligatory2),
	filterList(0, NotObligatory2, NotObligatory),
	%write('not obligatry chosen '),write(NotObligatory),nl,
	
	append(NotObligatory,Obligatory,AllCourses),     %append all courses together to scedule them at once
	%should be modified to have no oring
	helper(AllCourses,CourseSchedule,Slots,Pairs,SoftLabTut,CourseSemester,Soft), %scedule the courses
	%write('after helper '),nl,
	all_different(Slots),                             %each thing should have a diff slot 
	
	
	insertSort(Slots, SortedSlots),   %this to minimize the gaps 
	sum_gaps(SortedSlots,GapSum),
	dayOff(SortedSlots,DaysOff),
	
	
	DaysOff #>= 1,
	
	append(Slots,ChosenCoursesBinary,LabelingSlots),
	%what we will label on
	
	labeling([max(Sum),max(DaysOff),max(Soft)],LabelingSlots),%max(Sum),min(GapSum),max(DaysOff),max(Soft)
	write(Pairs).
	
schedule1(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule):-
		
	length(Result,L),
	length(ChosenCoursesBinary,L),
	ChosenCoursesBinary ins 0..1 ,%should have labeling on
	
	sum_up(ChosenCoursesBinary,Result,CHRS,Sum,1,NotObligatory1), %it takes 1) courses chosen 11011 2) result [3,5,10] courses i can take 3) CHRS  
	Sum #=<RemainingCH,
	labeling([max(Sum)],ChosenCoursesBinary),
	get_indices(ChosenCoursesBinary,Result,1,NotObligatory2),
	filterList(0, NotObligatory2, NotObligatory),
	%write('not obligatry chosen '),write(NotObligatory),nl,
	
	append(NotObligatory,Obligatory,AllCourses),     %append all courses together to scedule them at once
	%should be modified to have no oring
	helper(AllCourses,CourseSchedule,Slots,Pairs,SoftLabTut,CourseSemester,Soft), %scedule the courses
	%write('after helper '),nl,
	all_different(Slots),                             %each thing should have a diff slot 
	
	
	insertSort(Slots, SortedSlots),   %this to minimize the gaps 
	sum_gaps(SortedSlots,GapSum),
	dayOff(SortedSlots,DaysOff),
	
	
	DaysOff #>= 1,
	
	append(Slots,ChosenCoursesBinary,LabelingSlots),
	%what we will label on
	
	labeling([max(Sum),min(GapSum),max(Soft)],LabelingSlots),%max(Sum),min(GapSum),max(DaysOff),max(Soft)
	write(Pairs).

schedule0(RemainingCH  ,Obligatory ,CHRS,CourseSemester, CourseSchedule,Result,FinalScedule):-
		
	length(Result,L),
	length(ChosenCoursesBinary,L),
	ChosenCoursesBinary ins 0..1 ,%should have labeling on
	
	sum_up(ChosenCoursesBinary,Result,CHRS,Sum,1,NotObligatory1), %it takes 1) courses chosen 11011 2) result [3,5,10] courses i can take 3) CHRS  
	Sum #=<RemainingCH,
	labeling([max(Sum)],ChosenCoursesBinary),
	get_indices(ChosenCoursesBinary,Result,1,NotObligatory2),
	filterList(0, NotObligatory2, NotObligatory),
	%write('not obligatry chosen '),write(NotObligatory),nl,
	
	append(NotObligatory,Obligatory,AllCourses),     %append all courses together to scedule them at once
	%should be modified to have no oring
	helper(AllCourses,CourseSchedule,Slots,Pairs,SoftLabTut,CourseSemester,Soft), %scedule the courses
	%write('after helper '),nl,
	all_different(Slots),                             %each thing should have a diff slot 
	
	
	insertSort(Slots, SortedSlots),   %this to minimize the gaps 
	sum_gaps(SortedSlots,GapSum),
	dayOff(SortedSlots,DaysOff),
	
	
	DaysOff #>= 1,
	
	append(Slots,ChosenCoursesBinary,LabelingSlots),
	%what we will label on
	
	labeling([max(Sum),max(Soft)],LabelingSlots),%max(Sum),min(GapSum),max(DaysOff),max(Soft)
	write(Pairs).	
	
/*get_chosen_courses(ChosenCoursesBinary,[],I):-length(ChosenCoursesBinary,L),I #> L.	
get_chosen_courses(ChosenCoursesBinary,[H|Result],I):-
	length(ChosenCoursesBinary,L),I #=<L,
	element(I,ChosenCoursesBinary,Element),
	Element #=1 #==> H #= I, Element #= 0 #==> H #= 0,
	I2 #= I+1,get_chosen_courses(ChosenCoursesBinary,Result,I2).
	
get_chosen_courses(ChosenCoursesBinary,Result,I):-
	length(ChosenCoursesBinary,L),I #=<L,
	element(I,ChosenCoursesBinary,Element),
	Element #=0,I2 #= I+1,get_chosen_courses(ChosenCoursesBinary,Result,I2). */

sum_gaps([H],0).
sum_gaps([H1,H2|T],Sum):-
	Diff #= abs(H1-H2),
	sum_gaps([H2|T],Sum2),
	Sum #= Diff+Sum2.
	
%ChosenCoursesBinary,NotObligatoryCourses,CHRS,Sum,1	
sum_up(ChosenCoursesBinary,NotObligatoryCourses,CHRS,0,I,[]):-length(ChosenCoursesBinary,L),I > L.
sum_up(ChosenCoursesBinary,NotObligatoryCourses,CHRS,Sum,I,[H|T]):-% it should take 1) list of binary courses chosen 2) crhours of the courses 
	length(ChosenCoursesBinary,L),
	I =<L,
	I2 is I+1,
	sum_up(ChosenCoursesBinary,NotObligatoryCourses,CHRS,Sum2,I2,T),
	element(I,ChosenCoursesBinary,Binary),
	element(I,NotObligatoryCourses,CourseNo),
	element(CourseNo,CHRS,CH),
	H #= Binary * CourseNo,
	Sum #= Sum2 + Binary*CH.
	
get_indices(ChosenCoursesBinary,NotObligatoryCourses,I,[]):-length(ChosenCoursesBinary,L),I #> L.
get_indices(ChosenCoursesBinary,NotObligatoryCourses,I,[H|T]):-% it should take 1) list of binary courses chosen 2) crhours of the courses 
	length(ChosenCoursesBinary,L),
	I =<L,
	I2 is I+1,
	get_indices(ChosenCoursesBinary,NotObligatoryCourses,I2,T),
	nth1(I,ChosenCoursesBinary,Binary),
	nth1(I,NotObligatoryCourses,CourseNo),
	H is Binary * CourseNo.


are_identical(X, Y) :-
    X == Y.

filterList(A, In, Out) :-
    exclude(are_identical(A), In, Out).	
	
dayOff([H],0).
dayOff([H1,H2|T],Sum):-
	H11 #= H1-1,H22 #= H2-1,
	DayH1 #= H11 // 5,
	DayH2 #= H22 //5,
	%absolute(DayH1,DayH2,Diff),
	Diff #= abs(DayH1-DayH2),
	dayOff([H2|T],Sum2),
	Sum #= Diff+Sum2.
	

choose_other_courses(_,[],AllowedCH,[]).
choose_other_courses(_,_,0,[]).
choose_other_courses(CHS,[C|T],AllowedCH,[C|List]):-
	nth1(C,CHS,VCH),
	X is AllowedCH -VCH ,X #>= 0 ,AllowedCH2 #= AllowedCH -VCH ,choose_other_courses(CHS,T,AllowedCH2,List).

choose_other_courses(CHS,[C|T],AllowedCH,List):-
	nth1(C,CHS,VCH),
	X is AllowedCH -VCH ,X #< 0 ,choose_other_courses(CHS,T,AllowedCH,List).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%make the scedule	
helper(Obligatory,CourseSchedule,Slots,Pairs,SoftLabTut,CourseSemester,SoftSum):-
	%write('obligatory and not obigatory '),write(Obligatory),nl,
	schedule_obligatory(Obligatory,CourseSchedule,[],Slots,[],Pairs,SoftLabTut,CourseSemester),
	%make soft constrian to have courses of same semester with same groups
	%write('ana hina '),nl,
	sameSemester(Pairs,SoftSum).
	
sameSemester([],0).
sameSemester([(Slot,CodeValue,GroupNo,Semester)|T],Sum):-
	IsTut #= CodeValue mod 10,IsTut #> 2,
	sameSemesterHelper(GroupNo,Semester,T,S2),
	sameSemester(T,Sum2),
	Sum #= S2+Sum2.
sameSemester([(Slot,CodeValue,GroupNo,Semester)|T],Sum):-
	IsTut #= CodeValue mod 10,IsTut #=< 2,
	sameSemester(T,Sum).

sameSemesterHelper(GroupNo,Semester,[],0).	
sameSemesterHelper(GroupNo1,Semester1,[(Slot,CodeValue,GroupNo,Semester)|T],Sum):-
	IsTut #= CodeValue mod 10,IsTut #> 2,
	Semester #= Semester1 #/\ GroupNo1 #= GroupNo #<==> B1,
	sameSemesterHelper(GroupNo1,Semester1,T,Sum2),
	Sum #= B1+Sum2.
	
sameSemesterHelper(GroupNo1,Semester1,[(Slot,CodeValue,GroupNo,Semester)|T],Sum):-
	IsTut #= CodeValue mod 10,IsTut #=< 2,
	sameSemesterHelper(GroupNo1,Semester1,T,Sum).

		

	
get_last_digit(N,D):-
	Div #= N //10, Div #=< 0 , D #= N mod 10.
get_last_digit(N,D):-
	Div #= N //10, Div #>0,
	get_last_digit(Div,D).
		
	
schedule_obligatory([],CourseSchedule,Slot1,Slot1,Pairs1,Pairs1,0,_).
	
schedule_obligatory([H|T],CourseSchedule,Slots,S2,Pairs1,P2,TotlalSoft,CourseSemester):-%[H|T] are the courses numbers [1,2,3]
	%write('iam hereeeee'),nl,
	nth1(H,CourseSchedule,CS),
	nth1(H,CourseSemester,Semester),
	nth1(1,CS,Lec1Times),
	nth1(2,CS,Lec2Times),
	nth1(3,CS,Tut1Times),
	nth1(4,CS,Tut2Times),

	element(L1I,Lec1Times,L1),
	element(L2I,Lec2Times,L2),
	element(TI,Tut1Times,T1),
	element(LabI,Tut2Times,Lab1),
	%Soft constrin to have same tut and label
	
	LabI #= TI #<==> Soft,
	
	%write(L1),nl,write(L2),nl,write(T1),nl,write(Lab1),
	L1 #=< L2 ,
	T1 #=< Lab1,
	
	Lec1Value #= H *10 +1,
	Lec2Value #= H *10 +2,
	T1Value #= H *10 +3,
	Lab1Value #= H *10 +4,
	%write([L1,L2,T1,Lab1]),nl,
	delete_zeroes([L1,L2,T1,Lab1],LecLabs,[(L1,Lec1Value,L1I,Semester),(L2,Lec2Value,L2I,Semester),(T1,T1Value,TI,Semester),(Lab1,Lab1Value,LabI,Semester)],
	LecLabsPairs),
	%write('after deleting zeroes '),write(LecLabs),nl,
	append(Slots,LecLabs,SlotsNew),
	append(Pairs1,LecLabsPairs,PairsNew),
	schedule_obligatory(T,CourseSchedule,SlotsNew,S2,PairsNew,P2,Soft2,CourseSemester),
	TotlalSoft #= Soft + Soft2.
	
	
delete_zeroes([],[],[],[]).
delete_zeroes([H|T],[H|T2],[PH|PT],[PH|PTR]):-
	H #> 0 ,delete_zeroes(T,T2,PT,PTR).
delete_zeroes([H|T],T2,[PH|PT],PairsR):-
	H #< 1 ,delete_zeroes(T,T2,PT,PairsR).

% if predefined delte didnt work
delete_me([],[]).
delete_me([H|T],[H|T2]):-
	H #> 0,delete_me(T,T2).
delete_me([H|T],R):-
	H #=< 0,delete_me(T,R). 
	
zmin_deleted(Zs1,Zs0) :-
   same_length(Zs1,[_|Zs0]),
   maplist(#=<(Min),Zs1),
   select(Min,Zs1,Zs0).

%get remaining hours after subtracting the obligatory courses

remaining_hours(_,[],Allowed,Allowed).%write(Allowed),nl.
remaining_hours(CHRS,[H|T],Allowed,R):-
	nth1(H,CHRS,Element),
	Allowed2 is Allowed -  Element,
	remaining_hours(CHRS,T,Allowed2,R).

% should be in preprocessing step
courses_not_obligatory(Prequesities,History,Obligatory,[],Index):-%choose the courses who are not obligatory
	length(Prequesities,L),Index > L.
courses_not_obligatory(Prequesities,History,Obligatory,[Index|Result],Index):-
	length(Prequesities,L),Index =< L,
	nth1(Index,Prequesities,Pre),
	\+ member(Index,Obligatory),
	pass(Pre,History),
	Index2 is Index+1,
	courses_not_obligatory(Prequesities,History,Obligatory,Result,Index2).

courses_not_obligatory(Prequesities,History,Obligatory,Result,Index):-
	length(Prequesities,L),Index =< L,
	nth1(Index,Prequesities,Pre),
	member(Index,Obligatory),
	Index2 is Index+1,
	courses_not_obligatory(Prequesities,History,Obligatory,Result,Index2);
	length(Prequesities,L),Index =< L,
	nth1(Index,Prequesities,Pre),
	\+ pass(Pre,History),
	Index2 is Index+1,
	courses_not_obligatory(Prequesities,History,Obligatory,Result,Index2).

pass([],_).
pass([H|T],History):-
	nth1(H,History,Grade),
	Grade \= f,
	pass(T,History).


insertSort([], []). 
insertSort([H|List], Result) :-
        insertSort(List, Temp), 
        %printlist(Temp),    
        insertItem(H, Temp, Result).
                  
    insertItem(X, [H|List], [H|Result]) :-
        H #< X, !, 
        insertItem(X, List, Result).
    insertItem(X, List, [X|List]).    
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	
%convert to binary
/*
dec_bin(0,'0').
dec_bin(1,'1').
dec_bin(N,B):-N>1,X is N mod 2,Y is N//2,dec_bin(Y,B1),atom_concat(B1, X, B).

decimal_binary(0,[0]).
decimal_binary(1,[1]).
decimal_binary(N,B):-
N>1,X is N mod 2,Y is N//2,decimal_binary(Y,B1),append(B1,[X],B).%atom_concat(B1, X, B).
*/




sum_all([],0).	
sum_all([H|T],R):-
	sum_all(T,R2),
	R #= H + R2.
	
/*pow(_,0,1).
	pow(X,Y,Z) :- Y1 is Y - 1,
              pow(X,Y1,Z1), Z is Z1*X.*/
	
%summation any ist we havea predcalled sum
test(2,[]).	
test(K,[H|T]):-
	K #= 1 #==> H= [] ,K #= 0 #==> H #= 0 ,K2 #= K+1,test(K2,T).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sceduling letures and tut with diff permutaions 


	




