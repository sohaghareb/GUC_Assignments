import os
from bottle import route, request, static_file, run
from xlrd import open_workbook
import subprocess
#  <form action="/upload" method="post" enctype="multipart/form-data">
#   Category:      <input type="text" name="category" />
#   Select a file: <input type="file" name="upload" />
#   <input type="submit" value="Start upload" />
# </form>
############################################################## start parsing
def fill_zeroes(code_number, course_schedule):
    array=course_schedule.get(code_number)
    for i in range(len(array)):
        if(len(array[i]) == 0):
            array[i].append(0)
    return array
def concatinate_string_array(course_schedule):
    result="["
    #print(course_schedule.keys())
    for key in course_schedule.keys():

        if(key >1):
            result+=','
        array=course_schedule.get(key)
        result+="[" #fatha el course nafso
        for i in range(len(array)):
            if(i>0 ):
                result+=","
            result+="[" #each mi3ad inside the course
            for j in range(len(array[i])):
                if(j>0):
                    result+=","
                result+=str(array[i][j])

            result+="]" #afla el mi3ad inside the course


        result+="]" #afla el course nafso





    result +="]"
    print('parsed excel is ')
    print(result)
    return result




def get_scedule_array(s):
    wb = open_workbook(s)
    code_number = 0
    course_number_mapping = {}
    course_schedule = {}
    old_course_code = ""
    for s in wb.sheets():
        #print 'Sheet:',s.name
        #print(s.__str__())
        for row in range(s.nrows):
            col_value = []
            if (row == 0):
                continue
            for col in range(s.ncols):
                value  = (s.cell(row,col).value)
                if(col ==0):
                    if(value != old_course_code):
                        old_course_code=value
                        if(code_number != 0 ):
                            new_array = fill_zeroes(code_number, course_schedule)
                            course_schedule.__setitem__(code_number, new_array)
                            print('course no ',code_number,' code: ',course_number_mapping.get(code_number),' ',course_schedule.get(code_number))
                        code_number+=1
                        course_number_mapping.__setitem__(code_number,value)
                        course_schedule.__setitem__(code_number,[[],[],[],[]])


                #print(value)
                try : value = str(int(value))
                except : pass
                col_value.append(value)
            #print(col_value)
            slot=(int(col_value[2])-1)*5 +int(col_value[3])
            index=0
            if(col_value[4] == "Tutorial1"):
                index=2
            elif(col_value[4] == "Lab1" or col_value[4]== "Tutorial2"):
                index=3
            elif(col_value[4] == "Lecture2"):
                index=1
            course_schedule.get(code_number)[index].append(slot)
            print(col_value,' ',row,' ',col)


    #print(course_schedule)
    new_array = fill_zeroes(code_number, course_schedule)
    course_schedule.__setitem__(code_number, new_array)
    #print('course no ', code_number, ' code: ', course_number_mapping.get(code_number), ' ',
         # course_schedule.get(code_number))
    result=concatinate_string_array(course_schedule)
    return result,course_number_mapping
#########################################################Parsing end
@route('/')
def root():
    return '''

    <!doctype html>
<html>
<head>
    <title>Timetable</title>
    <style type="text/css">
    body
    {
        font-family: arial;
    }

    th,td
    {
        margin: 0;
        text-align: center;
        border-collapse: collapse;
        outline: 1px solid #e3e3e3;
    }

    td
    {
        padding: 5px 10px;
    }

    th
    {
        background: #666;
        color: white;
        padding: 5px 10px;
    }

    td:hover
    {
        cursor: pointer;
        background: #666;
        color: white;
    }
    </style>

</head>
<body>
<form action="/upload" method="post" enctype="multipart/form-data">
<br>Please Enter Your ID<br>

 <input type="text" name="ID"><br>

<br> Please tick the desired options <br>

  <input type="checkbox" name="Gaps" value="Minimize Gaps"> Minimize Gaps<br>
  <input type="checkbox" name="Off" value="Maximize Days off" > Maximize Days off<br>
  <input type="submit" value="Submit">

<input type="file" name="upload"><br>
</form>


    '''

@route('/upload', method='POST')
def do_upload():
    upload = request.files.get('upload')
    id=request.forms.get("ID")
    Gaps=request.forms.get("Gaps")
    Off = request.forms.get("Off")
    checked=0
    flag=0
    if(Gaps):
        flag=1
    flag2 = 0
    if (Off):
        flag2 = 1
    print('value of Gaps ',flag,' value of Off ',flag2)
    if(flag ==1  and flag2 == 0):
        checked=1
    elif(flag == 0 and flag2 ==1):
        checked=2
    elif(flag ==1  and flag2 ==1):
        checked=3

    #print(id)
    #name, ext = os.path.splitext(upload.filename)
    # if ext not in ('.png', '.jpg', '.jpeg'):
    #     return "File extension not allowed."
    save_path = "/tmp/{category}".format(category='.xlsx')
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    file_path = "{path}/{file}".format(path=save_path, file=upload.filename)
    if not os.path.exists(file_path):
        upload.save(file_path)
    path="/tmp/"+upload.filename
    scedule,course_mapping=get_scedule_array(file_path) #parse the filethis should be passed to prolog
    #############################################################################connect to prolog and get the output
    print('check value   ',checked)
    cmd = "swipl -g consult('Project2016tany.pl'),preprocessing(" +scedule+","+id+","+str(checked)+",FinalScedule),halt"
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
#    sss = p.stdout.readlines()
    sss=""
    for line in p.stdout.readlines():
        sss=line.decode("utf-8")
        print('hhh ',line)


    print(sss)

    ss = sss[2:len(sss) - 1]
    print(ss)
    print(ss)
    arr = ss.split(',')
    result = {}
    print(arr)
    # print(arr[4].split('('))
    i = 0
    while i < (len(arr)):
        slot_number = int(arr[i].split('(')[1])
        i += 1
        course_code_lab = arr[i]
        course_code = int(course_code_lab[:len(course_code_lab) - 1])
        type = int(course_code_lab[len(course_code_lab) - 1:len(course_code_lab)])
        i = i + 1
        group_number = int(arr[i])
        i = i + 1
        semester = int(arr[i].split(')')[0])
        print(slot_number, course_code, type, group_number, semester)
        i = i + 1
        value =course_mapping.get(course_code)+" \n sem:"+str(semester)+" group:"+str(group_number)
        if(type ==1):
            value+=" lec1"
        elif(type ==2):
            value+=" lec2"
        elif (type == 3):
            value += " Tut1"
        elif (type == 4):
            value += " Lab1/Tut2"
        result.__setitem__(slot_number, value)
    #print(result)
    return_schdule="<!doctype html><html><head><title>Timetable</title><style type='text/css'>body{font-family: arial;}th,td{margin: 0;text-align: center;border-collapse: collapse;outline: 1px solid #e3e3e3;}"
    return_schdule+="td {padding: 5px 10px;}th{background: #666;color: white;padding: 5px 10px;}td:hover{cursor: pointer;background: #666;color: white;}</style></head><body>"
    return_schdule+=" <table width='80%' align='center' ><div id='head_nav'><tr><th>Time</th><th>First</th><th>Second</th><th>Third</th><th>Fourth</th><th>Fifth</th></tr></div> <tr><th>Saturday </th>"
    if(result.__contains__(1)):
        return_schdule+="<td>"+result.get(1)+"</td>"
    else:
        return_schdule += "<td>"  + "</td>"
    if (result.__contains__(2)):
        return_schdule += "<td>" + result.get(2) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(3)):
        return_schdule += "<td>" + result.get(3) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(4)):
        return_schdule += "<td>" + result.get(4) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(5)):
        return_schdule += "<td>" + result.get(5) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"

    return_schdule+="</tr><tr><th>Sunday </th>"

    ########################################
    if (result.__contains__(6)):
        return_schdule += "<td>" + result.get(6) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(7)):
        return_schdule += "<td>" + result.get(7) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(8)):
        return_schdule += "<td>" + result.get(8) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(9)):
        return_schdule += "<td>" + result.get(9) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(10)):
        return_schdule += "<td>" + result.get(10) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"

    return_schdule += "</tr><tr><th>Monday Slot</th>"
    ##############################
    if (result.__contains__(11)):
        return_schdule += "<td>" + result.get(11) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(12)):
        return_schdule += "<td>" + result.get(12) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(13)):
        return_schdule += "<td>" + result.get(13) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(14)):
        return_schdule += "<td>" + result.get(14) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(15)):
        return_schdule += "<td>" + result.get(15) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"

    return_schdule += "</tr><tr><th>Tuesday</th>"
    #################################################################3
    if (result.__contains__(16)):
        return_schdule += "<td>" + result.get(16) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(17)):
        return_schdule += "<td>" + result.get(17) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(18)):
        return_schdule += "<td>" + result.get(18) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(19)):
        return_schdule += "<td>" + result.get(19) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(20)):
        return_schdule += "<td>" + result.get(20) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"

    return_schdule += "</tr><tr><th>Wednesday</th>"
######################################################################
    if (result.__contains__(21)):
        return_schdule += "<td>" + result.get(21) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(22)):
        return_schdule += "<td>" + result.get(22) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(23)):
        return_schdule += "<td>" + result.get(23) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(24)):
        return_schdule += "<td>" + result.get(24) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"
    if (result.__contains__(25)):
        return_schdule += "<td>" + result.get(25) + "</td>"
    else:
        return_schdule += "<td>" + "</td>"

    return_schdule += "</tr></table></body></html>"

    return return_schdule

if __name__ == '__main__':
    run(host='localhost', port=8080)